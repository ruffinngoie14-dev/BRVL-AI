"""Draw Fig. 1 from results/design_analysis.json."""
import json, os, sys
import numpy as np

def main(path, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"pdf.fonttype": 42, "font.family": "serif",
                         "font.serif": ["Times New Roman", "Liberation Serif", "TeX Gyre Termes", "DejaVu Serif"],
                         "mathtext.fontset": "stix", "font.size": 8,
                         "axes.spines.top": False, "axes.spines.right": False})
    res = json.load(open(path)); C = res["cells"]; RHOS = (0.10, 0.20, 0.30)
    fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.35))
    Ks = [4, 6, 8, 10, 12]
    cols = {0.10: "#4C7DB0", 0.20: "#D08A3C", 0.30: "#5E9E6E"}
    for rho, c in cols.items():
        for d, ls, lab in ((0.5, "-", fr"$\rho_0$ = {rho:.2f}"), (0.3, "--", None)):
            pw = np.array([C[f"K{K}_rho{rho}_d{d}"]["reject_cluster"] for K in Ks])
            ax[0].plot(Ks, pw, color=c, ls=ls, lw=1.3, marker="o", ms=2.5, label=lab)
    ax[0].axhline(0.8, color="0.6", lw=0.6, ls=":")
    ax[0].set_xticks(Ks); ax[0].set_ylim(0, 1)
    ax[0].set_xlabel("schools per arm (about 15 pupils measured per school)")
    ax[0].set_ylabel("power, AI+T vs AI")
    ax[0].set_title("(a) solid: d = 0.5; dashed: d = 0.3", fontsize=7.5)
    ax[0].legend(frameon=False, fontsize=6.5, loc="lower right")
    x = np.arange(3)
    ax[1].bar(x - 0.18, [C[f"planned_rho{r}_d0.0"]["reject_naive"] for r in RHOS], 0.34,
              color="#C9D7E8", edgecolor="#4C7DB0", label="pupil-level ANCOVA")
    ax[1].bar(x + 0.18, [C[f"planned_rho{r}_d0.0"]["reject_cluster"] for r in RHOS], 0.34,
              color="#F1DCC2", edgecolor="#D08A3C", label="school-level analysis")
    ax[1].axhline(0.05, color="0.3", lw=0.7, ls="--")
    ax[1].set_xticks(x); ax[1].set_xticklabels([fr"$\rho_0$ = {r:.2f}" for r in RHOS])
    ax[1].set_ylabel("false-positive rate (true d = 0)")
    ax[1].set_title("(b) earlier plan, 2 vs 2 schools of 30", fontsize=7.5)
    ax[1].set_ylim(0, 0.40)
    ax[1].legend(frameon=False, fontsize=6.5, loc="upper left", ncol=2)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "fig1_power.pdf")); fig.savefig(os.path.join(out, "fig1_power.png"), dpi=300)



if __name__ == "__main__":
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
    main(os.path.join(here, "design_analysis.json"), here)
