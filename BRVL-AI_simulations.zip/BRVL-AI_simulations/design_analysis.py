"""Design analysis for the BRVL-AI cluster-randomised trial (A2MRA 2027), version 2.

Monte Carlo study of the Q2 contrast (AI+T vs AI) and of the gender equivalence test.

Protocol choices made to avoid circularity:
  * The data-generating model is not the analysis model. Scores are produced item by item
    from a three-parameter logistic (3PL) IRT model with guessing (5-option items),
    on two parallel 20-item forms, so scores are bounded, discrete and measured with error.
  * The pretest-posttest correlation and the intraclass correlation of the analysed outcome
    are NOT inputs; they emerge from the latent model and are reported as outputs.
  * Schools differ in baseline level AND in growth (teacher/school heterogeneity), cluster
    sizes vary, and lower-scoring pupils are more likely to miss the posttest (MAR attrition).
  * Power is estimated by simulation of the pre-specified analysis, not by a closed formula.
  * No value is taken from the project's earlier (simulated) data file.
  * 20,000 replicates per cell, independent random streams per cell, Monte Carlo SE reported.
  * The cluster-level analysis is cross-checked against a REML mixed model on a subset.

Run: python3 design_analysis.py   (about 15-25 min)  -> results/design_analysis.json, fig1_power.pdf/png
"""
import json, os, time
import numpy as np
from scipy import stats

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)
MASTER = np.random.SeedSequence(20271304)
R = 20000            # replicates per cell
CHUNK = 1000
ALPHA = 0.05
N_ITEMS = 20

# ---- fixed item bank (drawn once) -----------------------------------------------------
_items = np.random.default_rng(MASTER.spawn(1)[0])
A_PRE = _items.uniform(0.8, 2.0, N_ITEMS)
B_PRE = _items.normal(0.0, 1.0, N_ITEMS)
A_POST = A_PRE * _items.uniform(0.9, 1.1, N_ITEMS)          # parallel form
B_POST = B_PRE + _items.normal(0.0, 0.2, N_ITEMS)
C_GUESS = 0.20

# ---- latent model parameters (on the scale of baseline ability, SD = 1) ----------------
GROWTH = 0.6        # mean growth over 7 weeks in all arms
SD_SCHOOL_GROWTH = np.sqrt(0.05)   # between-school (teacher) variation in growth
SD_PUPIL_GROWTH = 0.5              # individual variation in growth
ATTR_MEAN = 0.10                   # posttest missing rate, higher for low pretest


def scores(theta, a, b, rng):
    """theta (...,) -> number correct on 20 3PL items."""
    p = C_GUESS + (1 - C_GUESS) / (1 + np.exp(-1.7 * a * (theta[..., None] - b)))
    return (rng.random(p.shape) < p).sum(-1).astype(float)


def gen_trial(rng, n_rep, k_arm, n_arms, m_nominal, d_vec, rho, fixed_m=False, sgv=None):
    """Generate n_rep trials. Returns pre, post (NaN if missing or absent), arm index per school,
    sex, mask of present pupils. Shapes (n_rep, J, Mmax)."""
    J = k_arm * n_arms
    if fixed_m:
        m = np.full((n_rep, J), m_nominal)
    else:  # measured pupils per school: consent and presence vary
        m = rng.binomial(int(round(m_nominal / 0.75)), 0.75, (n_rep, J))
        m = np.maximum(m, 3)
    Mmax = int(m.max())
    present = np.arange(Mmax)[None, None, :] < m[..., None]
    arm = np.repeat(np.arange(n_arms), k_arm)                     # school -> arm
    u = rng.normal(0, np.sqrt(rho), (n_rep, J, 1))
    e = rng.normal(0, np.sqrt(1 - rho), (n_rep, J, Mmax))
    theta0 = u + e
    v = rng.normal(0, SD_SCHOOL_GROWTH if sgv is None else np.sqrt(sgv), (n_rep, J, 1))
    w = rng.normal(0, SD_PUPIL_GROWTH, (n_rep, J, Mmax))
    eff = np.asarray(d_vec)[arm][None, :, None]
    theta1 = theta0 + GROWTH + eff + v + w
    pre = scores(theta0, A_PRE, B_PRE, rng)
    post = scores(theta1, A_POST, B_POST, rng)
    # MAR attrition: logit P(missing) = c - 0.5 * z(pre)
    z = (pre - 10.0) / 4.0
    c = np.log(ATTR_MEAN / (1 - ATTR_MEAN))
    miss = rng.random(post.shape) < 1 / (1 + np.exp(-(c - 0.5 * z)))
    sex = rng.random(post.shape) < 0.5
    post = np.where(present & ~miss, post, np.nan)
    pre = np.where(present, pre, np.nan)
    return pre, post, arm, sex


def analyse_two_arm(pre, post, arm):
    """Naive pupil-level ANCOVA and cluster-level two-stage analysis. Returns p-values and
    descriptive outputs, all vectorised over replicates."""
    n_rep, J, M = post.shape
    ok = ~np.isnan(post)
    T = np.broadcast_to((arm == 1)[None, :, None], post.shape)
    # flatten
    y = np.where(ok, post, 0.0); x = np.where(ok, pre, 0.0); t = np.where(ok, T, 0.0)
    n = ok.sum((1, 2)).astype(float)
    def s(a): return a.sum((1, 2))
    # OLS y ~ 1 + t + x via normal equations (3x3) per replicate
    X = np.stack([ok.astype(float), t, x], -1)                        # (R,J,M,3)
    XtX = np.einsum('rjmi,rjmk->rik', X, X)
    Xty = np.einsum('rjmi,rjm->ri', X, y)
    beta = np.linalg.solve(XtX, Xty[..., None])[..., 0]
    fit = np.einsum('rjmi,ri->rjm', X, beta)
    res = np.where(ok, y - fit, 0.0)
    sigma2 = s(res ** 2) / (n - 3)
    se_t = np.sqrt(sigma2 * np.linalg.inv(XtX)[:, 1, 1])
    p_naive = 2 * stats.t.sf(np.abs(beta[:, 1] / se_t), n - 3)
    # cluster-level: pooled regression y ~ x (no arm), residual means per school, t-test
    xm = s(x) / n; ym = s(y) / n
    sxy = s(np.where(ok, (x - xm[:, None, None]) * (y - ym[:, None, None]), 0))
    sxx = s(np.where(ok, (x - xm[:, None, None]) ** 2, 0))
    b1 = sxy / sxx
    r2 = np.where(ok, y - ym[:, None, None] - b1[:, None, None] * (x - xm[:, None, None]), 0)
    cnt = ok.sum(2)
    cm = r2.sum(2) / np.maximum(cnt, 1)                                # (R,J) school means
    g1 = cm[:, arm == 1]; g0 = cm[:, arm == 0]
    p_cluster = stats.ttest_ind(g1, g0, axis=1).pvalue
    # descriptive outputs that were NOT inputs
    r_prepost = sxy / np.sqrt(sxx * s(np.where(ok, (y - ym[:, None, None]) ** 2, 0)))
    # ICC of adjusted outcome (ANOVA estimator on residuals r2)
    k = cnt.astype(float)
    grand = r2.sum((1, 2)) / n
    ssb = (k * (cm - grand[:, None]) ** 2).sum(1)
    ssw = s(np.where(ok, (r2 - cm[..., None]) ** 2, 0))
    msb = ssb / (J - 1); msw = ssw / (n - J)
    k0 = (n - (k ** 2).sum(1) / n) / (J - 1)
    icc_adj = (msb - msw) / (msb + (k0 - 1) * msw)
    sd_post = np.sqrt(s(np.where(ok, (y - ym[:, None, None]) ** 2, 0)) / (n - 1))
    return p_naive, p_cluster, r_prepost, icc_adj, sd_post, beta[:, 1]


def run_cell(seed, k_arm, m_nominal, d, rho, fixed_m=False, sgv=None):
    rng = np.random.default_rng(seed)
    out = {k: [] for k in ("pn", "pc", "r", "icc", "sd", "b")}
    for _ in range(R // CHUNK):
        pre, post, arm, _ = gen_trial(rng, CHUNK, k_arm, 2, m_nominal, [0.0, d], rho, fixed_m, sgv)
        pn, pc, r, icc, sd, b = analyse_two_arm(pre, post, arm)
        for key, val in zip(out, (pn, pc, r, icc, sd, b)):
            out[key].append(val)
    o = {k: np.concatenate(v) for k, v in out.items()}
    rej_n = float(np.mean(o["pn"] < ALPHA)); rej_c = float(np.mean(o["pc"] < ALPHA))
    rej_c2 = float(np.mean(o["pc"] < ALPHA / 2))
    mcse = lambda p: float(np.sqrt(p * (1 - p) / R))
    return {"reject_naive": rej_n, "mcse_naive": mcse(rej_n),
            "reject_cluster": rej_c, "mcse_cluster": mcse(rej_c),
            "reject_cluster_alpha0.025": rej_c2,
            "mean_r_prepost": float(np.mean(o["r"])), "mean_icc_adjusted": float(np.nanmean(o["icc"])),
            "observed_effect_sd": float(np.mean(o["b"] / o["sd"]))}


cells = []
RHOS = (0.10, 0.20, 0.30)
DS = (0.0, 0.3, 0.5)
for rho in RHOS:
    for d in DS:
        cells.append(("planned", 2, 30, d, rho, True))
for K in (4, 6, 8, 10, 12):
    for rho in RHOS:
        for d in DS:
            cells.append((f"K{K}", K, 15, d, rho, False))
seeds = MASTER.spawn(len(cells) + 20)[1:]

res = {"settings": {"replicates_per_cell": R, "alpha": ALPHA, "items": N_ITEMS, "guessing": C_GUESS,
                    "growth": GROWTH, "school_growth_var": SD_SCHOOL_GROWTH ** 2,
                    "pupil_growth_sd": SD_PUPIL_GROWTH, "attrition_mean": ATTR_MEAN,
                    "rho_baseline_latent": RHOS, "d_latent": DS},
       "cells": {}}
t0 = time.time()
for (lab, K, m, d, rho, fixed), sd in zip(cells, seeds):
    key = f"{lab}_rho{rho}_d{d}"
    res["cells"][key] = run_cell(sd, K, m, d, rho, fixed)
    print(key, res["cells"][key], f"{time.time() - t0:.0f}s", flush=True)

# ---- sensitivity: between-school variance of growth (teacher effect), K = 10, rho0 = 0.2 ----
res["sensitivity_school_growth_var"] = {}
for i, sgv in enumerate((0.0, 0.05, 0.10, 0.15)):
    for d in (0.0, 0.5):
        res["sensitivity_school_growth_var"][f"sgv{sgv}_d{d}"] = run_cell(seeds[-10 - 2 * i - (d > 0)], 10, 15, d, 0.2, False, sgv)
print("sens", res["sensitivity_school_growth_var"], flush=True)

# ---- cross-check: REML mixed model vs cluster-level analysis on 1,000 replicates ----------
import warnings, statsmodels.formula.api as smf, pandas as pd
warnings.filterwarnings("ignore")
def mixed_check(seed, K, d, rho, n=1000):
    rng = np.random.default_rng(seed)
    pre, post, arm, _ = gen_trial(rng, n, K, 2, 15, [0.0, d], rho)
    pn, pc, *_ = analyse_two_arm(pre, post, arm)
    pm = np.empty(n)
    for i in range(n):
        ok = ~np.isnan(post[i])
        jj, mm = np.nonzero(ok)
        df = pd.DataFrame({"y": post[i][ok], "x": pre[i][ok], "t": (arm[jj] == 1).astype(float), "s": jj})
        f = smf.mixedlm("y ~ t + x", df, groups=df["s"]).fit(reml=True)
        tv = f.params["t"] / f.bse["t"]
        pm[i] = 2 * stats.t.sf(abs(tv), 2 * K - 3)   # between-within df
    return {"reject_mixed": float(np.mean(pm < ALPHA)), "reject_cluster": float(np.mean(pc < ALPHA)),
            "agreement": float(np.mean((pm < ALPHA) == (pc < ALPHA))), "n": n}
res["mixed_model_check"] = {"K10_rho0.2_d0.0": mixed_check(seeds[-1], 10, 0.0, 0.2),
                            "K10_rho0.2_d0.5": mixed_check(seeds[-2], 10, 0.5, 0.2)}
print("mixed", res["mixed_model_check"], flush=True)

# ---- gender equivalence (TOST) in the full three-arm trial, K = 10, m = 15 ----------------
def tost_cell(seed, rho, margin=0.25, n_rep=R):
    rng = np.random.default_rng(seed)
    rej_pool, rej_arm = [], []
    for _ in range(n_rep // CHUNK):
        pre, post, arm, sex = gen_trial(rng, CHUNK, 10, 3, 15, [0.0, 0.3, 0.5], rho)
        for which, store in (("pool", rej_pool), ("arm", rej_arm)):
            keep = np.ones(arm.shape, bool) if which == "pool" else (arm == 2)
            p, y, sx = pre[:, keep], post[:, keep], sex[:, keep]
            ok = ~np.isnan(y)
            J = p.shape[1]
            # y ~ pre + sex + school fixed effects, by within-school demeaning
            def dm(a):
                a = np.where(ok, a, 0.0); c = ok.sum(2, keepdims=True)
                return np.where(ok, a - a.sum(2, keepdims=True) / np.maximum(c, 1), 0.0)
            Y, X1, X2 = dm(y), dm(p), dm(sx.astype(float))
            S = lambda a, b: (a * b).sum((1, 2))
            XtX = np.stack([np.stack([S(X1, X1), S(X1, X2)], -1), np.stack([S(X2, X1), S(X2, X2)], -1)], -2)
            Xty = np.stack([S(X1, Y), S(X2, Y)], -1)
            b = np.linalg.solve(XtX, Xty[..., None])[..., 0]
            resid = Y - b[:, 0, None, None] * X1 - b[:, 1, None, None] * X2
            n = ok.sum((1, 2)); dfree = n - J - 2
            s2 = S(resid, resid) / dfree
            se = np.sqrt(s2 * np.linalg.inv(XtX)[:, 1, 1])
            yy = np.where(ok, y, np.nan); sdy = np.nanstd(yy.reshape(CHUNK, -1), axis=1, ddof=1)
            mg = margin * sdy
            p1 = stats.t.sf((b[:, 1] + mg) / se, dfree); p2 = stats.t.cdf((b[:, 1] - mg) / se, dfree)
            store.append(np.maximum(p1, p2) < ALPHA)
    a = float(np.mean(np.concatenate(rej_pool))); c = float(np.mean(np.concatenate(rej_arm)))
    return {"equivalence_power_pooled_450": a, "equivalence_power_one_arm_150": c,
            "mcse_max": float(np.sqrt(0.25 / n_rep))}
res["tost_gender"] = {f"rho{r}": tost_cell(seeds[-3 - i], r) for i, r in enumerate(RHOS)}
print("tost", res["tost_gender"], flush=True)

with open(os.path.join(OUT, "design_analysis.json"), "w") as f:
    json.dump(res, f, indent=2)

# ---- figure: see plot_figure.py (reads the JSON) ----
import plot_figure
plot_figure.main(os.path.join(OUT, "design_analysis.json"), OUT)
print("done", f"{time.time() - t0:.0f}s")
