# Design analysis for the BRVL-AI trial (A2MRA 2027)

## Files
- `design_analysis.py`: full Monte Carlo study (about 8 minutes on one core).
- `plot_figure.py`: redraws Fig. 1 from `results/design_analysis.json` without rerunning the study.
- `results/design_analysis.json`: every number quoted in Section 4 and Table 1 of the paper.
- `results/fig1_power.pdf`, `results/fig1_power.png`: Fig. 1.

## Requirements
Python 3.10 or later, numpy, scipy, pandas, statsmodels, matplotlib.

```
pip install numpy scipy pandas statsmodels matplotlib
python3 design_analysis.py
```

## Protocol
- Answers are generated item by item (20-item parallel forms, 3PL model with guessing 0.2). Schools differ in baseline level (rho0 = 0.10, 0.20, 0.30) and in growth (variance 0.05; 0, 0.10 and 0.15 in the sensitivity runs). Cluster sizes are binomial with mean 15, and posttest attrition is 10% on average, higher for weak pupils (missing at random given the pretest).
- The analysis model (linear ANCOVA) differs from the generating model. The pretest-posttest correlation and the residual intraclass correlation are outputs, not inputs.
- Each replicate is analysed twice: a pupil-level ANCOVA that ignores schools, and a two-stage school-level analysis with a t-test on 2K-2 degrees of freedom. A REML mixed model is compared with the school-level analysis on 1,000 replicates per condition.
- Each cell uses 20,000 replicates drawn from its own random stream (numpy SeedSequence 20271304). The Monte Carlo standard error is at most 0.0035.
- No value comes from the earlier simulated data file.

## Key for `results/design_analysis.json`
- `cells`: one key per cell, named `<design>_rho<rho0>_d<d>`. `planned` is the earlier plan (2 vs 2 schools of 30 pupils); `K<n>` has n schools per arm.
- `reject_naive`, `reject_cluster`: rejection rates at alpha = 0.05 (false-positive rate when d = 0, power otherwise).
- `reject_cluster_alpha0.025`: school-level rejection rate at alpha = 0.025, the first Holm step.
- `mean_r_prepost`, `mean_icc_adjusted`, `observed_effect_sd`: quantities that emerge from the simulated data.
- `sensitivity_school_growth_var`: 10 schools per arm, rho0 = 0.20, with the growth variance varied.
- `mixed_model_check`: agreement between the mixed model and the school-level analysis.
- `tost_gender`: power of the gender equivalence test (margin 0.25 SD) on the pooled trial and within one arm.
